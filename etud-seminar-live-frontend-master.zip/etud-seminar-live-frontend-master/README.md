ssh ubuntu@18.156.176.251 -i socketserver.pem


import Vue from 'vue'
import Chart from 'vue-prism'
import 'prismjs/themes/prism.css'
import JsonExcel from 'vue-json-excel'
import ICS from 'vue-ics'
import VueTheMask from 'vue-the-mask'
import { rtdbPlugin } from 'vuefire'
import VueJsPanel from 'vue-js-panel/src'
import 'jspanel4/dist/jspanel.min.css'

Vue.use(VueJsPanel)
Vue.use(rtdbPlugin)
Vue.use(VueTheMask)
Vue.use(ICS, {
  uidDomain: null,
  prodId: null
})

// Similar to Vue.use()
Chart.install(Vue)
Vue.component('downloadExcel', JsonExcel)

import Vue from 'vue'
import VueSocketIOExt from 'vue-socket.io-extended'
import io from 'socket.io-client'

const socket = io('https://socket.etud.online')
Vue.use(VueSocketIOExt, socket)

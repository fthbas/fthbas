import enUS from './en'
import trTR from './tr'

export default {
  en: enUS,
  tr: trTR
}

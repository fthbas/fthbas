export default {
  login: 'Giriş Yap',
  register: 'Kayıt Formu',
  save: 'Kayıt Ol',
  pleaseSelect: 'Lütfen Seçiniz',
  password: 'Parola',
  sendCode: 'Kod Gönder',
  enterPassword: 'Parolayı Giriniz',
  enter: 'Giriş',
  invalidPassword: 'Hatalı Parola',
  invalidPhone: 'Hatalı Telefon',
  invalidCode: 'Hatalı Kod',
  survey: 'Anket',
  askQuestion: 'Soru Sor'
}

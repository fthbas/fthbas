export default {
  editProfile: 'Profilini Düzenle',
  passwordLeaveBlank: '* Şifre kısmını boş bırakırsanız şifreniz güncellenmeyecektir.'
}

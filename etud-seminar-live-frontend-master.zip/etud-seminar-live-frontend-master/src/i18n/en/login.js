export default {
  login: 'Log In',
  register: 'Register',
  save: 'Register',
  pleaseSelect: 'Please Select',
  sendCode: 'Send Code',
  password: 'Password',
  enterPassword: 'Enter Password',
  enter: 'Log In',
  invalidPassword: 'Invalid Password',
  invalidPhone: 'Invalid Phone',
  invalidCode: 'Invalid Code',
  survey: 'Survey',
  askQuestion: 'ASK QUESTION'
}

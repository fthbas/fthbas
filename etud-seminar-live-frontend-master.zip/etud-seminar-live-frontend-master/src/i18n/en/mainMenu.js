export default {
  dashboard: 'Kontrol Paneli',
  contacts: 'Kişiler',
  tagManagement: 'Tag Yönetimi',
  marketing: 'Pazarlama',
  forms: 'Formlar',
  audiences: 'Kitleler',
  analytics: 'Analitik',
  touches: 'Touch Yönetimi',
  billing: 'Faturalandırma',
  settings: 'Ayarlar',
  integrations: 'Entegrasyonlar',
  myProfile: 'Profilim',
  signOut: 'Çıkış Yap'
}

export default {
  forms: 'Formlar',
  manual: 'Manuel',
  twitter: 'Twitter',
  facebook: 'Facebook',
  linkedin: 'Linkedin',
  newsletter: 'Bülten',
  identify: 'Identify Tagı'
}

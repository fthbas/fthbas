export default {
  marketing: 'Pazarlama',
  newsletter: 'Haber Bülteni',
  companyNews: 'Şirket Haberleri',
  common: 'Genel',
  misc: {
    subs: 'Abonelikleri',
    email: 'E-Postaları',
    sms: 'SMS\'leri',
    push: 'Push Bildirimleri',
    call: 'Aramaları',
    whatsapp: 'Whatsapp Mesajları'
  },
  miscs: {
    subs: 'Abonelikler',
    email: 'E-Postalar',
    sms: 'SMS\'ler',
    push: 'Push Bildirimleri',
    call: 'Aramalar',
    whatsapp: 'Whatsapp Mesajları'
  }
}

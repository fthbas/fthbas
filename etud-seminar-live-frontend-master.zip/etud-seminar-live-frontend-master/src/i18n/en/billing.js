export default {
  header: 'Faturalandırma',
  headerDesc: 'Fatura detaylarınızı görün ve ödeme yapın',
  credits: 'Toplam Kredi',
  marketing: 'Toplam Pazarlama',
  email: 'Toplam E-Mail',
  sms: 'Total Sms'
}

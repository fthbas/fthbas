export default {
  tablet: 'Tablet',
  mobile: 'Mobil',
  desktop: 'Masaüstü',
  tv: 'TV'
}

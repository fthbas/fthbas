export default {
  'tr-tr': 'Türkçe - TR',
  'en-us': 'İngilizce - EN'
}

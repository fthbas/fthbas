export default {
  myAccount: 'Hesabım',
  signedInAs: '<strong>{email}</strong> olarak giriş yapıldı.',
  notifications: {
    newTouchCreated: 'Yeni Touch oluşturuldu!',
    byTimeAgo: '<span class="text-weight-bold">{email}</span> tarafından yaklaşık {time}'
  }
}

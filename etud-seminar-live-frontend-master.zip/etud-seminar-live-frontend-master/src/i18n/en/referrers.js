export default {
  social: 'Sosyal Medya',
  search: 'Arama Ağları',
  email: 'E-Posta'
}

export default {
  name: 'Adı (UTM Name)',
  campaign: 'Kampanya (UTM Campaign)',
  term: 'Terimler (UTM Term)',
  medium: 'Medyum (UTM Medium)',
  source: 'Kaynak (UTM Source)',
  content: 'İçerik (UTM Content)'
}

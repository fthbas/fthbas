export default {
  header: 'Entegrasyonlar',
  headerDesc: 'Entegrasyonlarınızı yönetin'
}

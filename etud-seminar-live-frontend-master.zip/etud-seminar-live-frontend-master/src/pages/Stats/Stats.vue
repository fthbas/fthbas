<template>
  <q-layout class="bg-grey-2" key="main-layout" view="hhh Lpr fFf">
    <q-header class="bg-white text-grey-8 q-py-xs shadow-1" height-hint="58">
      <q-toolbar :style="{height: $q.screen.gt.sm ? '60px': '50px'}">
        <q-btn v-if="project" flat @click="miniMode = !miniMode" round dense :icon="miniMode ? 'chevron_right' : 'chevron_left'" />
      </q-toolbar>
    </q-header>
    <q-drawer
      v-if="project"
      v-model="drawer"
      show-if-above
      :mini="!drawer || miniMode"
      :width="200"
      :breakpoint="100"
      bordered
      content-class="bg-white q-py-md shadow-1"
    >
      <q-scroll-area class="fit">
        <q-list>
          <template v-for="(menuItem, index) in menuList">
            <q-item v-if="menuItem.enabled" active-class="text-primary" @click="routeOrLogout(menuItem.tab)"  style="color: #616161; font-weight: 400; border-bottom-right-radius: 15px; border-top-right-radius: 15px;"  :key="index" clickable :active="menuItem.tab === tab" v-ripple>
              <q-tooltip anchor="center right" self="center left"  v-if="miniMode">{{ menuItem.label }}</q-tooltip>
              <q-item-section avatar >
                <q-icon :name="menuItem.icon" />
              </q-item-section>
              <q-item-section>
                {{ menuItem.label }}
              </q-item-section>
            </q-item>
            <q-separator :key="'sep' + index"  v-if="menuItem.separator" />
          </template>
        </q-list>
      </q-scroll-area>
    </q-drawer>
    <q-page-container>
      <div v-if="manager_active === true">
        <div class="row q-mt-xl custom-bg">
          <div class="col"></div>
          <div class="col col-lg-4 col-md-6 col-sm-9 col-xs-12">
            <q-card>
              <q-card-section>
                <div class="text-h5 text-weight-bolder text-center text-grey-9 q-my-lg">Panele Aynı Anda 1 Kişi Giriş Yapabilir, Bir Hata Olduğunu Düşünüyorsanız Lütfen İletişime Geçiniz</div>
              </q-card-section>
            </q-card>
          </div>
          <div class="col"></div>
        </div>
      </div>
      <div v-else-if="pass_confirmed && project && manager_active === false">
        <div class="row q-col-gutter-md">
          <div class="col-12 q-mt-md" v-if="tab==='common'">
            <div class="row q-col-gutter-md q-px-xl q-mb-md">
              <div class="col-6">
                <q-card>
                  <q-item style="background-color: #3a9688" class="q-pa-none">
                    <q-item-section class=" q-pa-md q-ml-none  text-white">
                      <q-item-label class="text-white text-h6 text-weight-bolder">{{uniqueVisitors}}</q-item-label>
                      <q-item-label>Toplam Benzersiz Kişi Sayısı</q-item-label>
                    </q-item-section>
                    <q-item-section side class="q-mr-md text-white">
                      <q-icon name="las la-users" color="white" size="54px"></q-icon>
                    </q-item-section>
                  </q-item>
                </q-card>
              </div>
              <div class="col-6">
                <q-card>
                  <q-item style="background-color: #3a9688" class="q-pa-none">
                    <q-item-section class=" q-pa-md q-ml-none  text-white">
                      <q-item-label class="text-white text-h6 text-weight-bolder">{{totalVisitors}}</q-item-label>
                      <q-item-label>Toplam Ziyaret Sayısı</q-item-label>
                    </q-item-section>
                    <q-item-section side class="q-mr-md text-white">
                      <q-icon name="las la-users" color="white" size="54px"></q-icon>
                    </q-item-section>
                  </q-item>
                </q-card>
              </div>
            </div>
            <q-separator></q-separator>
            <div v-if="$route.name === 'projects.stats'" class="row q-col-gutter-md q-px-md q-pt-md">
                <div class="col col-12">
                  <q-btn class="full-width" color="red-9" unelevated @click="promptRefreshPage = !promptRefreshPage" icon-right="las la-skull-crossbones" icon="las la-skull-crossbones" label="Canlı Yayına Bağlı Tüm Seyircilerin Ekranlarını Yenile (Toplam Ziyaret Sayısını Etkiler)"></q-btn>
                  <q-dialog v-model="promptRefreshPage" persistent>
                    <q-card style="min-width: 350px">
                      <q-card-section>
                        <div class="text-h6">Canlı Yayındaki Herkesin Ekranını Yenilemek İstediğinize Emin Misiniz?</div>
                        <p class="text-caption text-red-10">Dikkat! Bu işlem sonucunda toplam ziyaret sayısı istatistiğini etkileyecek ve şu an canlı yayında bulunan kişi sayısı kadar arttıracaktır.</p>
                      </q-card-section>
                      <q-card-section class="q-pt-none">
                        <q-input label="Parolayı Giriniz" type="password" dense v-model="passRefreshPage" autofocus  />
                      </q-card-section>
                      <q-card-actions align="right" class="text-primary">
                        <q-btn flat label="Vazgeç" v-close-popup />
                        <q-btn flat label="Yenile" @click="doRefreshPlease" />
                      </q-card-actions>
                    </q-card>
                  </q-dialog>
                </div>
                <div class="col col-auto">
                  <q-btn class="full-width"
                         @click="()=>{
                         this.$q.dialog({
                            title: 'Onayla',
                            message: 'Kayıtlı kişiler sıfırlansın m?',
                            cancel: true,
                            persistent: true
                          }).onOk(() => {
                            resetStats('contacts')
                          })
                       }"
                         color="red-9" unelevated label="Kayıtlı Kişileri Sıfırla"></q-btn>
                </div>
                <div class="col col-auto">
                  <q-btn class="full-width"
                         @click="()=>{
                         this.$q.dialog({
                            title: 'Onayla',
                            message: 'Sorulan sorular sıfırlansın mı?',
                            cancel: true,
                            persistent: true
                          }).onOk(() => {
                            resetStats('questions')
                          })
                       }"
                         color="red-9" unelevated label="Sorulan Soruları Sıfırla"></q-btn>
                </div>
                <div class="col col-auto">
                  <q-btn class="full-width"
                         @click="()=>{
                         this.$q.dialog({
                            title: 'Onayla',
                            message: 'Anket cevapları sıfırlansın mı?',
                            cancel: true,
                            persistent: true
                          }).onOk(() => {
                            resetStats('surveys')
                          })
                       }"
                         color="red-9" unelevated label="Anket Cevaplarını Sıfırla"></q-btn>
                </div>
                <div class="col col-auto">
                  <q-btn class="full-width"
                         @click="()=>{
                         this.$q.dialog({
                            title: 'Onayla',
                            message: 'Test cevapları sıfırlansın mı?',
                            cancel: true,
                            persistent: true
                          }).onOk(() => {
                            resetStats('test_answers')
                          })
                       }"
                         color="red-9" unelevated label="Test Cevaplarını Sıfırla"></q-btn>
                </div>
                <div class="col col-auto">
                  <q-btn class="full-width"
                         @click="()=>{
                         this.$q.dialog({
                            title: 'Onayla',
                            message: 'Giriş çıkış kayıtları sıfırlansın mı?',
                            cancel: true,
                            persistent: true
                          }).onOk(() => {
                            resetStats('visitor_logs')
                          })
                       }"
                         color="red-9" unelevated label="Giriş Çıkış Kayıtlarını Sıfırla"></q-btn>
                </div>
              </div>
          </div>
          <div class="col-12" v-if="tab==='call_to_action'">
            <q-card bordered class="my-card bg-grey-1">
                <q-card-section>
                  <div class="row items-center no-wrap">
                    <div class="col">
                      <div class="text-h6">Eylem Çağrısı</div>
                    </div>
                  </div>
                </q-card-section>
                <q-separator></q-separator>
                <q-card-section>
                  <q-input clearable outlined v-model="call_to_action.title" label="Başlık"></q-input>
                  <q-editor class="q-mt-md" v-model="call_to_action.text" min-height="10rem" />
                </q-card-section>
                <q-separator />
                <q-card-actions>
                  <q-btn @click="callToAct" color="green-8">Gönder</q-btn>
                </q-card-actions>
              </q-card>
          </div>
          <div class="col-12" v-if="tab==='status_checker'">
            <q-card bordered class="my-card bg-grey-1">
              <q-card-section>
                <div class="row items-center no-wrap">
                  <div class="col">
                    <div class="text-h6">Durum Yöneticisi</div>
                  </div>
                </div>
              </q-card-section>
              <q-separator></q-separator>
              <q-card-section class="q-gutter-md">
                <q-input clearable outlined v-model="status_checker.title" label="Başlık"></q-input>
                <q-input clearable outlined v-model="status_checker.url" label="Onaylanmazsa Yönlendirilecek Adres (Boş bırakılırsa yönlendirme yapılmaz.)"></q-input>
                <q-input clearable outlined v-model="status_checker.button_text" label="Onaylama Butonu Metni"></q-input>
                <q-input type="number" clearable outlined v-model.number="status_checker.timer" label="Bekleme süresi (Saniye cinsinden)"></q-input>
                <q-editor class="q-mt-md" v-model="status_checker.text" min-height="10rem" />
              </q-card-section>
              <q-separator />
              <q-card-actions>
                <q-btn @click="statusCheck" color="green-8">Gönder</q-btn>
              </q-card-actions>
            </q-card>
          </div>
          <div class="col-12" v-if="tab==='questions' && project.ask_questions.enabled">
            <q-card flat>
              <q-card-section>
                <download-excel
                  name="Sorular.xls"
                  type="xls"
                  :data="questions"
                  :fields="questionFields"
                >
                  <q-btn
                    color="primary"
                    icon-right="archive"
                    label="Soruları Excel'e Aktar"
                    no-caps
                  />
                </download-excel>
              </q-card-section>
              <q-card-section>
                <q-list>
                  <q-item :key="qkey" v-for="(question, qkey ) in questions">
                    <q-item-section>
                      <q-item-label  style="font-size: 16px;">{{ question.first_name }} {{ question.last_name }} - {{ question.email }} || {{ question.lang && project.languages.find(x => x.value === question.lang) ? project.languages.find(x => x.value === question.lang).label : '' }}</q-item-label>
                      <p class="text-grey-8 q-pa-xs" style="font-size: 14px;">{{
                          question.q
                        }}.</p>
                      <div class="row">
                        <div class="col">
                          <q-toggle
                            style="font-size: 12px;"
                            :label="'Bu soru cevaplandı mı!'"
                            color="orange-8"
                            v-model="question.answered"
                            :true-value="true"
                            :false-value="false"
                            :val="false"
                            @input="saveQuestion(question)"
                          />
                        </div>
                        <div class="col-auto">    <q-rating
                          v-model="question.approve"
                          max="5"
                          size="3.5em"
                          color="yellow"
                          icon="star_border"
                          icon-selected="star"
                          @input="saveQuestion(question)"
                          icon-half="star_half"
                          no-dimming
                        /></div>
                      </div>
                      <q-separator></q-separator>
                    </q-item-section>
                    <q-item-section side top>
                      <q-item-label caption>{{ moment(question.created_at).locale('tr').fromNow() }}</q-item-label>
                      <q-icon class="cursor-pointer" name="las la-copy" color="grey-8" @click="()=>{copyToClipboard(
                                 question.first_name + ' ' + question.last_name + ' - ' + question.email + '-' + question.phone + ' | ' +question.q
                        ); $q.notify({
                        message: 'Soru Kopyalandı',
                        color: 'green-8',
                        position: 'top'
                      })}" />
                    </q-item-section>
                  </q-item>
                </q-list>
              </q-card-section>
            </q-card>
          </div>
          <div class="col-12" v-if="tab==='survey' && project.survey.enabled">
            <q-card flat>
              <q-card-section>
                <download-excel
                  name="Anket Cevapları.xls"
                  type="xls"
                  :data="survey"
                  :fields="surveyFields"
                >
                  <q-btn
                    color="primary"
                    icon-right="archive"
                    label="Anket Cevaplarını Excel'e Aktar"
                    no-caps
                  />
                </download-excel>
              </q-card-section>
              <q-card-section>
                <q-list>
                  <q-expansion-item
                    :key="skey" v-for="(survey, skey ) in survey"
                    expand-separator
                    expand-icon-class="text-black"
                    expand-icon="las la-chevron-circle-down"
                    icon="perm_identity"
                    style="border-bottom: 2px solid #dedede;"
                    :label="(survey.first_name || '_') + ' ' + (survey.last_name || '_') +  ' - '+ (survey.email || '_')"
                    :caption="moment(survey.created_at).locale('tr').fromNow()"
                  >
                    <q-item>
                      <q-item-section>
                        <q-item-label class="text-subtitle2 text-grey-8" :key="suskey" v-for="(sur, suskey) in survey">
                        <span v-if="['vid', '_id', 'pass', 'project', 'created_at', 'questions'].indexOf(suskey) < 0">
                          <span style="text-transform: capitalize;">{{ titleCase(suskey) }} </span>: {{Array.isArray(sur) ? sur.join(', ') : sur}}
                        </span>
                        </q-item-label>
                      </q-item-section>
                    </q-item>
                  </q-expansion-item>
                </q-list>
              </q-card-section>
            </q-card>
          </div>
          <div class="col-12" v-if="tab==='qa' && project.qa_enabled">
            <q-card flat>
              <q-card-section>
                <q-btn
                  color="green-8"
                  icon-right="save"
                  @click="saveProject"
                  label="Değişiklikleri Kaydet"
                  no-caps
                />
              </q-card-section>
              <q-card-section class="text-grey-8 shadow-2">
                <div class="row q-col-gutter-lg">
                  <div class="col-auto">
                    <q-btn  @click="addTestPart = !addTestPart" color="green-8" label="Yeni Test Ekle"></q-btn>
                    <q-dialog v-model="addTestPart" persistent>
                      <q-card style="min-width: 350px">
                        <q-card-section>
                          <div class="text-h6">Test Adı</div>
                        </q-card-section>
                        <q-card-section class="q-pt-none">
                          <q-input dense v-model="newTestName" autofocus />
                        </q-card-section>
                        <q-card-actions align="right" class="text-primary">
                          <q-btn flat label="İptal" v-close-popup />
                          <q-btn @click="() => {project.qa.parts[new Date().getTime()]  = { active: false, time_counter:20, qa_popup_timer: 20, name: newTestName, questions: []}; newTestName = ''; }" flat label="Ekle" v-close-popup />
                        </q-card-actions>
                      </q-card>
                    </q-dialog>
                  </div>
                </div>
              </q-card-section>
              <q-separator></q-separator>
              <q-card-section>
                <q-tabs
                  v-model="qa"
                  indicator-color="primary"
                  content-class="text-weight-bold"
                  class="text-dark"
                >
                  <q-tab v-for="(questionPart, questionPartKey) in project.qa.parts" :key="questionPartKey" :name="questionPartKey" :label="questionPart.name" />
                </q-tabs>
                <div v-for="(questionPart, questionPartKey) in project.qa.parts" :key="questionPartKey" >
                  <!--  İStatistik ve cevaplar-->
                  <q-dialog persistent
                            full-width
                            :maximized="true"
                            transition-show="slide-up"
                            transition-hide="slide-down" v-model="answersModal[questionPartKey]" >
                    <q-card flat>
                      <q-card-section class="text-grey-8 shadow-2">
                        <div class="row items-center no-wrap">
                          <div class="col">
                            <div class="text-h6">{{ questionPart.name}} Testine Verilen Cevaplar</div>
                          </div>
                          <div class="col-auto">
                            <q-btn icon="close" @click="()=> {answersModal[questionPartKey] = !answersModal[questionPartKey]; $forceUpdate()}" flat round dense v-close-popup />
                          </div>
                        </div>
                      </q-card-section>
                      <q-separator></q-separator>
                      <q-card-section class="q-pt-xs no-margin no-padding" v-if="qaAnswers">
                        <div style="border-bottom: 5px solid #ec6222; padding: 15px; " :key="questionAnswerKey" v-for="(data, questionAnswerKey)  in qaAnswers.filter(x => x.pkey === questionPartKey)">
                          <div class="row" style="padding: 5px;">
                            <div class="col-12" >
                              İsim Soyisim: {{ data.visitor[0] ? data.visitor[0].first_name : 'İsim yok' }} {{ data.visitor[0] ? data.visitor[0].last_name : 'Soyisim yok' }}
                            </div>
                            <div class="col-12">
                              E-Posta: {{ data.visitor[0] ? data.visitor[0].email : 'E-mail yok' }}
                            </div>
                            <div class="col-12">
                              Cevap Saati: {{ moment(data.created_at).locale('tr').format('DD-MM-YYYY HH:mm:ss.SSS')}}
                            </div>
                          </div>
                          <div class="row" style="border-top: 1px dashed #000; padding: 5px;" :key="questionKey" v-for="(question, questionKey) in questionPart.questions">
                            <div class="col-12">
                              {{question.question}}
                            </div>
                            <div class="col-12" v-if="question.type !== 'string'">
                              <div class="q-gutter-xs">
                                <q-chip
                                  :key="qoptkey"
                                  :color="(qopt.name === data.data[question.key] && qopt.is_correct )? 'green' : (qopt.name === data.data[question.key]  && !qopt.is_correct ? 'red' : 'grey') "
                                  v-for="(qopt, qoptkey) in question.options" :icon="qopt.is_correct ? 'las la-check' : 'las la-ban' ">
                                    {{qopt.name}}
                                </q-chip>
                              </div>
                            </div>
                            <div class="col-12" v-else>
                              <div class="q-gutter-xs">
                                <q-chip color="green" icon="las la-check">
                                  {{data.data[question.key]}}
                                </q-chip>
                              </div>
                            </div>
                          </div>
                        </div>
                      </q-card-section>
                    </q-card>
                  </q-dialog>
                  <q-dialog persistent
                            full-width
                            :maximized="true"
                            transition-show="slide-up"
                            transition-hide="slide-down" v-model="answerStatModal[questionPartKey]" >
                    <q-card flat>
                      <q-card-section class="text-grey-8 shadow-2">
                        <div class="row items-center no-wrap">
                          <div class="col">
                            <div class="text-h6">{{ questionPart.name}} Testi Cevap İstatistikleri</div>
                          </div>
                          <div class="col-auto">
                            <q-btn icon="close" @click="()=> {answerStatModal[questionPartKey] = !answerStatModal[questionPartKey]; $forceUpdate()}" flat round dense v-close-popup />
                          </div>
                        </div>
                      </q-card-section>
                      <q-separator></q-separator>
                      <q-card-section class="q-pt-xs no-margin no-padding" v-if="qaAnswers">
                        <div class="row" style="border-top: 1px dashed #000; padding: 5px;" :key="questionKey" v-for="(question, questionKey) in questionPart.questions">
                            <div v-if="question.type !== 'string'" class="col-12">
                              {{question.question}}
                            </div>
                            <div v-if="question.type !== 'string'" class="col-12" >
                              <div class="q-gutter-xs">
                                <q-chip
                                  :key="qoptkey"
                                  color="green-2"
                                  size="md"
                                  text-color="black"
                                  v-for="(qopt, qoptkey) in question.options">
                                  {{qopt.name}} | Cevap Sayısı: {{getAnswerStats(questionPartKey, question.key, qopt.name)}}
                                </q-chip>
                              </div>
                            </div>
                          </div>
                      </q-card-section>
                    </q-card>
                  </q-dialog>
                  <!--  İStatistik ve cevaplar-->
                  <div v-if="qa === questionPartKey">
                    <div class="row">
                      <div class="col-12 q-pt-md q-gutter-xs">
                        <q-input bottom-slots clearable outlined v-model.number.trim="questionPart.qa_popup_timer" label="Test soruları kutusunun saniye cinsinden yayın ekranında kalma süresi.">
                          <template v-slot:hint>
                            Boş bırakırsanız popup ekranda 20 saniye kalır. Kullanıcı kapatana kadar kapanmaması için çok uzun bir süre girebilirsiniz.
                            1 saat = 3600 saniye.
                          </template>
                        </q-input>
                        <q-btn @click="deleteQaPart(questionPartKey)" push color="red-8" label="Testi Sil" icon="las la-trash" ></q-btn>
                        <q-btn :disable="questionPart.active" @click="openQa(questionPartKey)" push color="blue-8" :label="'Yayın Ekranında Aç ('+ questionPart.time_counter +')'" ></q-btn>
                        <q-btn :disable="!questionPart.active" @click="closeQa(questionPartKey)" push color="blue-8" label="Yayın Ekranında Kapat" ></q-btn>
                        <q-btn @click="editTestPart = !editTestPart" push color="pink-5" label="İsmi Düzenle" >
                          <q-dialog v-model="editTestPart" persistent>
                            <q-card style="min-width: 350px">
                              <q-card-section>
                                <div class="text-h6">Test Adı</div>
                              </q-card-section>
                              <q-card-section class="q-pt-none">
                                <q-input dense v-model="questionPart.name" autofocus />
                              </q-card-section>
                              <q-card-actions align="right" class="text-primary">
                                <q-btn flat label="İptal" v-close-popup />
                                <q-btn @click="() => {saveProject()}" flat label="Değişiklikleri Kaydet" v-close-popup />
                              </q-card-actions>
                            </q-card>
                          </q-dialog>
                        </q-btn>
                        <q-btn align="around" class="btn-fixed-width" push color="green-8" label="Yeni Soru Ekle" icon="las la-plus" >
                          <q-tooltip anchor="top middle" transition-show="flip-right" transition-hide="flip-left" self="center middle">
                            {{ $t('buttons.createNewQuestion') }}
                          </q-tooltip>
                          <q-menu>
                            <div  :key="'key_' + key" v-for="(questionType, key) in questionTypes" >
                              <div class="row">
                                <q-btn class="full-width q-pa-xs q-btn--no-uppercase" unelevated align="left" size="md" :text-color="questionType.color" @click="addQuestionToQaForm(questionPartKey, questionType.name)" :icon="questionType.icon" :label="questionType.label"></q-btn>
                              </div>
                              <q-separator v-if="questionType.seperator"></q-separator>
                            </div>
                          </q-menu>
                        </q-btn>
                        <q-btn @click="openAnswerModal(questionPartKey)" push color="purple-8" label="Cevapları Gör" icon="las la-question" ></q-btn>
                        <q-btn @click="openAnswerStatModal(questionPartKey)" push color="cyan-8" label="Cevap istatistiklerini Gör" icon="las la-question" ></q-btn>
                        <download-excel
                          v-if="qaAnswers"
                          name="Test Cevapları.xls"
                          type="xls"
                          style="width: 320px; display: inline; margin-top:3px;"
                          :data="qaAnswers.filter(x=>x.part_data.name === questionPart.name)"
                          :fields="qaFields[questionPart.name]"
                        >
                          <q-btn
                            color="primary"
                            push
                            icon-right="archive"
                            style="margin-top:3px;"
                            label="Cevapları Excel'e Aktar"
                          />
                        </download-excel>
                      </div>
                      <div class="col-md-12 col-sm-12 col-xs-12 q-pt-md" v-for="(question, questionPartQuestionKey) in project.qa.parts[questionPartKey].questions" :key="'key_' + questionPartQuestionKey" >
                          <q-card>
                            <q-list>
                              <q-expansion-item switch-toggle-side class="text-grey-8" icon="explore" group="questions">
                                <q-separator />
                                <template v-slot:header>
                                  <q-item-section avatar class="handle" style="cursor: grab;" v-if="$q.screen.gt.xs">
                                    <q-avatar icon="la la-arrows-alt-v" style="min-width: 25px; padding-right:0;" />
                                  </q-item-section>
                                  <q-item-section class="handle" style="cursor: grab;">
                                  <span style="font-size: 16px;">
                                    <q-icon style="margin-bottom: 4px; font-size: 22px;" :color="questionTypes.find(x=>x.name === question.type).color" :class="['q-pr-xs', questionTypes.find(x=>x.name === question.type).icon]" >
                                      <q-tooltip anchor="top left" self="center left" transition-show="flip-right" transition-hide="flip-left">
                                        {{ question.type.toUpperCase() }}
                                      </q-tooltip>
                                    </q-icon>
                                    <span v-html="question.question"></span>
                                  </span>
                                    <small v-if="question.description">{{question.description}}</small>
                                  </q-item-section>
                                </template>
                                <q-card>
                                  <q-card-section>
                                    <div class="row">
                                      <div class="col-md-4 col-sm-12 col-xs-12 q-pa-md">
                                        <q-editor v-model="project.qa.parts[questionPartKey].questions[questionPartQuestionKey].question" :placeholder="$t('inputs.question')" min-height="10rem" />
                                        <q-input clearable outlined class="q-pt-md" v-model="project.qa.parts[questionPartKey].questions[questionPartQuestionKey].description" :label="$t('inputs.questionDesc')" type="textarea"></q-input>
                                        <div v-if="['selectbox', 'checkbox', 'radio'].indexOf(project.qa.parts[questionPartKey].questions[questionPartQuestionKey].type) > -1">
                                          <q-input outlined clearable @keyup.enter="newValueToQaOptions(questionPartKey, questionPartQuestionKey); $forceUpdate()" v-model="qaOptionLabel" class="q-py-sm"  :label="$t('forms.addNewOption')">
                                            <template v-slot:after>
                                              <q-btn @click="newValueToQaOptions(questionPartKey, questionPartQuestionKey); $forceUpdate()" color="green-8" unelevated flat icon="la la-plus" />
                                            </template>
                                          </q-input>
                                          <q-input v-model="project.qa.parts[questionPartKey].questions[questionPartQuestionKey].options[option_key].name" outlined clearable :key="option_key" v-for="(option, option_key) in project.qa.parts[questionPartKey].questions[questionPartQuestionKey].options" class="q-py-sm"  :label="$t('forms.typeYourOption')">
                                            <template v-slot:after>
                                              <q-btn @click="removeValueFromQaOptions(questionPartKey, questionPartQuestionKey, option_key);" color="red-8" unelevated flat icon="la la-trash" />
                                              <q-toggle
                                                style="font-size: 12px;"
                                                @input="() => { $forceUpdate() }"
                                                :label="'Bu doğru cevap!'"
                                                color="orange-8"
                                                v-model="project.qa.parts[questionPartKey].questions[questionPartQuestionKey].options[option_key].is_correct"
                                                :true-value="true"
                                                :false-value="false"
                                                :val="false"
                                              />
                                            </template>
                                          </q-input>
                                        </div>
                                        <q-toggle
                                          :label="$t('forms.isQuestionRequired')"
                                          color="orange-8"
                                          @input="() => { $forceUpdate() }"
                                          v-model="project.qa.parts[questionPartKey].questions[questionPartQuestionKey].is_required"
                                          :true-value="true"
                                          :false-value="false"
                                          :val="false"
                                        />
                                        <q-separator></q-separator>
                                        <q-btn
                                          unelevated
                                          :label="$t('buttons.deleteQuestion')"
                                          text-color="red-4"
                                          size="md"
                                          class="q-btn--no-uppercase"
                                          icon="la la-trash"
                                          @click="deleteQaQuestion(questionPartKey, questionPartQuestionKey)"
                                        />
                                      </div>
                                    </div>
                                  </q-card-section>
                                </q-card>
                                <q-separator />
                              </q-expansion-item>
                            </q-list>
                          </q-card>
                        </div>
                    </div>
                  </div>
                </div>
              </q-card-section>
            </q-card>
          </div>
          <!-- -->
          <div class="col-12" v-if="tab==='visitors' && ['register_mail', 'register_enter', 'excel_list_field', 'register_sms'].includes(project.login_type.value)">
            <q-table
              flat
              :pagination="{rowsPerPage:10}"
              separator="horizontal"
              :data="registeredVisitors"
              :columns="registeredVisitorCols"
              row-key="name"
              @row-click="registeredVisitorsRowClick"
            >
              <template v-slot:top-right>
                <download-excel
                  name="Kayıtlar.xls"
                  type="xls"
                  :data="registeredVisitorsForExcel"
                  :fields="excelFields"
                >
                  <q-btn
                    color="primary"
                    icon-right="archive"
                    label="Kayıtları Excel'e Aktar"
                    no-caps
                  />
                </download-excel>
              </template>
            </q-table>
          </div>
          <div class="col-12" v-if="tab==='visitor_logs'  && ['register_mail', 'register_enter', 'excel_list_field', 'register_sms'].includes(project.login_type.value)">
            <q-table
              flat
              :pagination="{rowsPerPage:50}"
              separator="horizontal"
              :data="visitorLogs ? visitorLogs.filter(x => x.visitor[0]) : []"
              :columns="visitorLogCols"
              row-key="name"
            >
              <template v-slot:top-right>
                <download-excel
                  name="Giriş Çıkış Kayıtları.xls"
                  type="xls"
                  :data="visitorLogs"
                  :fields="visitorLogFields"
                >
                  <q-btn
                    color="primary"
                    icon-right="archive"
                    label="Giriş / Çıkış Kayıtlarını Excel'e Aktar"
                    no-caps
                  />
                </download-excel>
              </template>
            </q-table>
          </div>
          <!-- -->
        </div>
      </div>
      <div v-else-if="!pass_confirmed && manager_active === false">
        <div class="row q-mt-xl custom-bg">
          <div class="col"></div>
          <div class="col col-lg-4 col-md-6 col-sm-9 col-xs-12">
            <q-card>
              <q-card-section>
                <div class="text-h5 text-weight-bolder text-center text-grey-9 q-my-lg">Giriş Yap</div>
              </q-card-section>
              <q-card-section>
                <q-input outlined  class="q-mt-sm" type="password" v-model="password" label="Şifre" />
                <q-space />
                <p class="text-red-8" >{{error}}</p>
                <q-btn @click="submit()"  class="full-width q-mt-sm q-pa-xs q-btn--no-uppercase"  style="font-size: 20px;" color="green-8"  label="Giriş Yap" />
              </q-card-section>
            </q-card>
          </div>
          <div class="col"></div>
        </div>
      </div>
      <q-dialog v-model="visitorEditPanel" persistent>
        <q-card style="min-width: 350px">
          <q-card-section>
            <h6 class="text-h6 text-grey-9">Silmek istediğinize emin misiniz?</h6>
          </q-card-section>
          <q-card-actions align="right" class="text-primary">
            <q-btn flat label="Vazgeç" v-close-popup />
            <q-btn flat label="Sil" @click="deleteContact" v-close-popup />
          </q-card-actions>
        </q-card>
      </q-dialog>
    </q-page-container>
  </q-layout>
</template>
<script>
import { copyToClipboard, exportFile } from 'quasar'
import moment from 'moment'

export default {
  created () {
    if (this.$route.name === 'projects.stats') {
      this.submit(this.$route.params.domain, this.$route.params.pass)
      this.manager_active = false
    } else {
      this.$socket.client.emit('statCheck', location.hostname)
    }
  },
  name: 'Stats',
  mounted () {
    // eslint-disable-next-line
    // window.$_REVECHAT_API.Button.hide()
  },
  data () {
    return {
      visitorEditPanel: false,
      visitorEditIndex: null,
      drawer: true,
      promptRefreshPage: false,
      passRefreshPage: null,
      manager_active: false,
      call_to_action: {
        title: '',
        text: ''
      },
      status_checker: {
        title: '',
        text: ''
      },
      miniMode: false,
      activeVisitors: null,
      addTestPart: false,
      editTestPart: false,
      newTestName: '',
      registeredVisitors: null,
      qa: 0,
      qaOptionLabel: '',
      tab: 'common',
      email_for_excel: '',
      pass_confirmed: false,
      copyToClipboard,
      exportFile,
      prompt: false,
      moment,
      counter: 0,
      questions: null,
      qaAnswers: null,
      qaStats: null,
      survey: null,
      visitorLogs: null,
      uniqueVisitors: 0,
      totalVisitors: 0,
      interval: null,
      answersModal: {},
      answerStatModal: {},
      polling: null,
      password: null,
      error: null
    }
  },
  beforeRouteLeave (to, from, next) {
    this.$store.dispatch('projects/clearProject')
    clearInterval(this.polling)
    if (this.$route.name !== 'projects.stats') {
      this.$socket.client.emit('statLeave')
    }
    next()
  },
  beforeDestroy () {
    clearInterval(this.polling)
  },
  sockets: {
    informYou (d) {
      this.counter = d
    },
    isManagerActive (d) {
      this.manager_active = d
    },
    uniqueVisitorCount (d) {
      this.uniqueVisitors = d[0].count
    },
    totalVisits (d) {
      this.totalVisitors = d[0].count
    },
    qa (d) {
      this.qaAnswers = d.sata
      this.qaStats = d.answers
    },
    visitorLogs (d) {
      this.visitorLogs = d
    },
    questions (d) {
      this.questions = d
    },
    registeredVisitors (d) {
      this.registeredVisitors = d
    },
    survey (d) {
      this.survey = d
    }
  },
  meta () {
    return {
      title: this.projectTitle,
      titleTemplate: title => `İstatistikler | ${title}`
    }
  },
  methods: {
    registeredVisitorsRowClick (event, row, index) {
      this.visitorEditIndex = index
      this.visitorEditPanel = true
    },
    deleteContact () {
      this.$q.notify({
        message: 'Kişi silindi.',
        color: 'green-8',
        position: 'top'
      })
      this.$store.dispatch('projects/deleteContact', { project: this.project.domain, contact: this.registeredVisitors[this.visitorEditIndex] })
      this.$socket.client.emit('informRegisteredVisitors', this.project.domain)
      this.visitorEditIndex = null
    },
    refreshEverybody () {
      this.$socket.client.emit('refreshEverybody', { domain: this.project.domain })
    },
    doRefreshPlease () {
      if (this.passRefreshPage === this.project.stats_password) {
        this.refreshEverybody()
        this.promptRefreshPage = false
        this.passRefreshPage = null
        this.$q.notify({
          message: 'Tüm yayın ekranları yenilendi',
          color: 'green-8',
          position: 'top'
        })
      } else {
        this.promptRefreshPage = false
        this.passRefreshPage = null
        this.$q.notify({
          message: 'Hatalı Parola',
          color: 'red-8',
          position: 'top'
        })
      }
    },
    getAnswerStats (partkey, question, answer) {
      if (this.qaStats && this.qaStats[partkey] && this.qaStats[partkey][question]) {
        const count = this.qaStats[partkey][question][0].find(x => x._id === answer)
        if (count) {
          return count.count
        } else {
          return 0
        }
      } else {
        return 0
      }
    },
    resetStats (type) {
      this.$store.dispatch('projects/resetStats', { project: this.project.domain, type })
    },
    routeOrLogout (tab) {
      if (tab === 'logout') {
        window.location.reload()
      } else {
        this.tab = tab
      }
    },
    callToAct () {
      this.$socket.client.emit('callToActEveryBody', { domain: this.project.domain, message: this.call_to_action })
      this.call_to_action = {
        title: '',
        text: ''
      }
    },
    statusCheck () {
      this.$socket.client.emit('statusCheckEveryBody', { domain: this.project.domain, message: this.status_checker })
    },
    snakeCase (string) {
      return string.replace(/\d+/g, ' ')
        .split(/ |\B(?=[A-Z])/)
        .map((word) => word.toLowerCase())
        .join('_')
    },
    openAnswerModal (qakey) {
      this.answersModal[qakey] = !this.answersModal[qakey]
      this.$forceUpdate()
    },
    openAnswerStatModal (qakey) {
      this.answerStatModal[qakey] = !this.answerStatModal[qakey]
      this.$forceUpdate()
    },
    saveProject (loading = true) {
      this.$store.dispatch('projects/saveProjectToFirebase', { key: this.project._id, project: this.project, loading })
    },
    saveQuestion (question) {
      this.$store.dispatch('projects/saveQuestion', { question: question })
    },
    newValueToQaOptions (qaKey, questionKey) {
      if (this.qaOptionLabel) {
        this.project.qa.parts[qaKey].questions[questionKey].options.push({
          name: this.qaOptionLabel
        })
        this.qaOptionLabel = ''
        this.$forceUpdate()
      }
    },
    removeValueFromQaOptions (qaKey, questionKey, optionKey) {
      this.$q.dialog({
        title: this.$t('forms.validation.questions.confirm'),
        message: 'Silmek istediğinize emin misiniz?',
        cancel: {
          label: this.$t('forms.validation.questions.cancel'),
          class: 'q-btn--no-uppercase',
          color: 'grey-2',
          textColor: 'blue'
        },
        ok: {
          label: this.$t('forms.validation.questions.delete'),
          classList: 'q-btn--no-uppercase',
          color: 'grey-2',
          textColor: 'red'
        },
        persistent: true
      }).onOk(() => {
        this.project.qa.parts[qaKey].questions[questionKey].options.splice(optionKey, 1)
        this.$forceUpdate()
      })
    },
    deleteQaQuestion (qaKey, key) {
      this.$q.dialog({
        title: this.$t('forms.validation.questions.confirm'),
        message: this.$t('forms.validation.questions.wouldYouLikeToDelete'),
        cancel: {
          label: this.$t('forms.validation.questions.cancel'),
          class: 'q-btn--no-uppercase',
          color: 'grey-2',
          textColor: 'blue'
        },
        ok: {
          label: this.$t('forms.validation.questions.delete'),
          classList: 'q-btn--no-uppercase',
          color: 'grey-2',
          textColor: 'red'
        },
        persistent: true
      }).onOk(() => {
        this.project.qa.parts[qaKey].questions.splice(key, 1)
        this.$forceUpdate()
      })
    },
    deleteQaPart (qaKey) {
      this.$q.dialog({
        title: this.$t('forms.validation.questions.confirm'),
        message: this.$t('forms.validation.questions.wouldYouLikeToDelete'),
        cancel: {
          label: this.$t('forms.validation.questions.cancel'),
          class: 'q-btn--no-uppercase',
          color: 'grey-2',
          textColor: 'blue'
        },
        ok: {
          label: this.$t('forms.validation.questions.delete'),
          classList: 'q-btn--no-uppercase',
          color: 'grey-2',
          textColor: 'red'
        },
        persistent: true
      }).onOk(() => {
        delete this.project.qa.parts[qaKey]
        this.$forceUpdate()
      })
    },
    addQuestionToQaForm (qaKey, type) {
      switch (type) {
        case 'string':
          this.project.qa.parts[qaKey].questions.push({
            question: this.$t('forms.sampleQuestions.string'),
            type: 'string',
            key: new Date().getTime(),
            is_required: false
          })
          break
        case 'selectbox':
          this.project.qa.parts[qaKey].questions.push({
            question: this.$t('forms.sampleQuestions.selectbox'),
            type: 'selectbox',
            key: new Date().getTime(),
            is_required: false,
            options: []
          })
          break
        case 'radio':
          this.project.qa.parts[qaKey].questions.push({
            question: this.$t('forms.sampleQuestions.radio'),
            type: 'radio',
            key: new Date().getTime(),
            options: [],
            is_required: false
          })
          break
      }
      this.$forceUpdate()
    },
    submit (hostname = null, password = null) {
      this.$store.dispatch('projects/fetchProjectByStats', { project: hostname || location.hostname, stats_password: password || this.password }).then(res => {
        for (let i = 0; i < res.qa.parts.length; i++) {
          this.answersModal[i] = false
        }
        this.pass_confirmed = true

        if (this.$route.name !== 'projects.stats') {
          this.$socket.client.emit('statsLoginActive', this.project.domain)
        }
        this.pollData()
        this.password = null
      }).catch(() => {
        this.error = 'Hatalı Şifre'
        this.pass_confirmed = false
      })
    },
    openQa (dKey) {
      this.project.qa.parts[dKey].active = true
      this.project.qa.parts[dKey].time_counter = this.project.qa.parts[dKey].qa_popup_timer
      const self = this
      this.interval = setInterval(function () {
        if (self.project.qa.parts[dKey].time_counter && self.project.qa.parts[dKey].time_counter > 0) {
          self.project.qa.parts[dKey].time_counter = self.project.qa.parts[dKey].time_counter - 1
          self.saveProject(false)
          self.$forceUpdate()
        } else {
          clearInterval(self.interval)
          self.closeQa(dKey)
          self.$forceUpdate()
        }
      }, 1000)
      this.saveProject(false)
      this.$forceUpdate()
    },
    closeQa (dKey) {
      this.project.qa.parts[dKey].active = false
      this.saveProject(false)
      clearInterval(this.interval)
      this.$forceUpdate()
    },
    titleCase (sentence) {
      const sentences = sentence.toLowerCase().split('_')
      return sentences.join(' ')
    },
    pollData () {
      this.$socket.client.emit('informUniqueVisitorCount', this.project.domain)
      this.$socket.client.emit('informTotalVisits', this.project.domain)
      this.$socket.client.emit('informQuestions', { domain: this.project.domain, show_on_visitor_screen: this.project.ask_questions.show_on_visitor_screen || false })
      this.$socket.client.emit('informRegisteredVisitorsNew', this.project.domain)
      // this.$socket.client.emit('informVisitorLogsNew', this.project)
      // this.$socket.client.emit('informQa', this.project.domain)
      this.polling = setInterval(() => {
        this.$socket.client.emit('informUniqueVisitorCount', this.project.domain)
        this.$socket.client.emit('informTotalVisits', this.project.domain)
        this.$socket.client.emit('informQuestions', { domain: this.project.domain, show_on_visitor_screen: this.project.ask_questions.show_on_visitor_screen || false })
        // this.$socket.client.emit('informQa', this.project.domain)
        // this.$socket.client.emit('informRegisteredVisitorsNew', this.project.domain)
        // this.$socket.client.emit('informVisitorLogsNew', this.project)
      }, 30000)
    }
  },
  computed: {
    errors () {
      return this.$store.state.users.errors
    },
    menuList () {
      return [
        {
          icon: 'las la-tachometer-alt',
          label: 'Genel İstatistikler',
          tab: 'common',
          enabled: true,
          separator: false
        },
        {
          icon: 'las la-question',
          label: 'Gelen Sorular',
          tab: 'questions',
          enabled: this.project.ask_questions.enabled,
          separator: false
        },
        {
          icon: 'las la-edit',
          label: 'Test Cevapları',
          tab: 'qa',
          enabled: this.project.qa_enabled,
          separator: false
        },
        {
          icon: 'las la-users',
          label: 'Kayıtlı Kişiler',
          tab: 'visitors',
          enabled: ['register_mail', 'register_enter', 'excel_list_field', 'register_sms'].includes(this.project.login_type.value),
          separator: false
        },
        // {
        //   icon: 'las la-sign-in-alt',
        //   label: 'Giriş-Çıkış Kayıtları',
        //   tab: 'visitor_logs',
        //   enabled: ['register_mail', 'register_enter', 'excel_list_field', 'register_sms'].includes(this.project.login_type.value),
        //   separator: true
        // },
        {
          icon: 'las la-times-circle',
          label: 'Çıkış Yap',
          tab: 'logout',
          enabled: true,
          separator: false
        }
      ]
    },
    registeredVisitorCols () {
      const lang = this.project.languages.find(x => x.deletable === false).value
      const columns = this.project.register_form.questions.map(x => {
        return {
          format: (val, row) => {
            if (val instanceof Array) {
              const values = val.map(x => x[lang])
              return values.join(', ')
            } else if (typeof val === 'object') {
              return val[lang]
            } else if (['string', 'integer'].includes(typeof val)) {
              return val
            }
          },
          align: 'left',
          name: x.meta ? x.meta.contact_field : x.key,
          label: x.question[lang],
          field: x.meta ? x.meta.contact_field : x.key,
          sortable: true
        }
      })
      const data = [...columns, { align: 'left', name: 'created_at', label: 'Kayıt Tarihi', field: 'created_at', sortable: true }]
      return data
    },
    visitorLogCols () {
      const colData = this.project.register_form.questions.map(x => {
        return {
          align: 'left',
          label: x.question,
          field: row => row.visitor[0][x.meta ? x.meta.contact_field : x.key],
          sortable: true
        }
      })
      colData.push({
        align: 'left',
        label: 'Giriş',
        field: row => row.login_at,
        sortable: true
      })
      colData.push({
        align: 'left',
        label: 'Çıkış',
        field: row => row.logout_at,
        sortable: true
      })
      return colData
    },
    registeredVisitorsForExcel () {
      const lang = this.project.languages.find(x => x.deletable === false).value
      return this.registeredVisitors.map(x => {
        for (const key of Object.keys(x)) {
          if (!['_id', 'project', 'created_at', 'updated_at'].includes(key)) {
            if (typeof x[key] === 'object') {
              x[key] = x[key][lang]
            }
          }
          if (key === 'draw') {
            x[key] = x[key].toString()
          }
        }
        return x
      })
    },
    excelFields () {
      const lang = this.project.languages.find(x => x.deletable === false).value
      const jsonFields = {
        'Tarih & Saat ': {
          field: 'created_at',
          callback: (value) => {
            return moment(value).locale('tr').format('YYYY-MM-DD HH:mm:ss.SSS')
          }
        }
      }
      for (let i = 0; i < this.project.register_form.questions.length; i++) {
        jsonFields[this.project.register_form.questions[i].question[lang]] = this.project.register_form.questions[i].meta ? this.project.register_form.questions[i].meta.contact_field : this.project.register_form.questions[i].key
      }
      jsonFields['Yayın Giriş URL'] = '__path'
      jsonFields['Parola (Eğer Parola Belirleme Özelliği Varsa)'] = 'password'
      jsonFields['Kayıt Ip Adresi'] = 'ip'
      jsonFields['Kayıt Olduğu Dil'] = 'lang'
      jsonFields['Kayıt Olduğu Tarayıcı'] = 'browser'
      jsonFields['Çekiliş Kodu (Otomatik Oluşturulur)'] = 'draw'
      return jsonFields
    },
    questionFields () {
      const jsonFields = {
        'Tarih & Saat ': {
          field: 'created_at',
          callback: (value) => {
            return value ? moment(value).locale('tr').format('DD.MM.YYYY HH:mm') : ''
          }
        },
        'Soru ': 'q',
        'İsim ': 'first_name',
        'Soyisim ': 'last_name',
        'E-Posta ': 'email',
        'Telefon ': 'phone',
        'Soruyu Sorduğu Tarayıcı ': 'browser',
        'Soruyu Sorduğu IP Adresi ': 'ip'
      }
      return jsonFields
    },
    surveyFields () {
      const jsonFields = {
        'Tarih & Saat ': {
          field: 'created_at',
          callback: (value) => {
            return value ? moment(value).locale('tr').format('DD.MM.YYYY HH:mm') : ''
          }
        },
        'İsim ': 'first_name',
        'Soyisim ': 'last_name',
        'E-Posta ': 'email',
        'Telefon ': 'phone'
      }
      for (let i = 0; i < this.project.survey.questions.length; i++) {
        jsonFields[this.project.survey.questions[i].question] = this.project.survey.questions[i].meta ? this.project.survey.questions[i].meta.contact_field : this.snakeCase(this.project.survey.questions[i].question)
      }
      jsonFields['Anketi Doldurduğu Tarayıcı '] = 'browser'
      jsonFields['Anketi Doldurduğu IP Adresi '] = 'ip'
      jsonFields['Benzersiz Tarayıcı Kimliği '] = 'vid'
      jsonFields['Yayın Şifresi '] = 'pass'
      return jsonFields
    },
    qaFields () {
      const jsonFields = {
      }
      for (const part in this.project.qa.parts) {
        jsonFields[this.project.qa.parts[part].name] = {
          'Tarih & Saat ': {
            field: 'created_at',
            callback: (value) => {
              return value ? moment(value).locale('tr').format('YYYY-MM-DD HH:mm:ss.SSS') : ''
            }
          },
          'İsim ': 'visitor.0.first_name',
          'Soyisim ': 'visitor.0.last_name',
          'E-Posta ': 'visitor.0.email'
        }
        for (let j = 0; j < this.project.qa.parts[part].questions.length; j++) {
          jsonFields[this.project.qa.parts[part].name][this.project.qa.parts[part].questions[j].question] = 'data.' + this.project.qa.parts[part].questions[j].key
        }
      }
      return jsonFields
    },
    visitorLogFields () {
      const lang = this.project.languages.find(x => x.deletable === false).value
      const jsonFields = {
      }
      for (let i = 0; i < this.project.register_form.questions.length; i++) {
        jsonFields[this.project.register_form.questions[i].question[lang]] = 'visitor.0.' + (this.project.register_form.questions[i].meta ? this.project.register_form.questions[i].meta.contact_field : this.project.register_form.questions[i].key)
      }
      jsonFields['Giriş '] =
      {
        field: 'login_at',
        callback: (value) => {
          return value ? moment(value).locale('tr').format('DD.MM.YYYY HH:mm') : ''
        }
      }
      jsonFields['Çıkış '] =
      {
        field: 'logout_at',
        callback: (value) => {
          return value ? moment(value).locale('tr').format('DD.MM.YYYY HH:mm') : ''
        }
      }
      jsonFields['Giriş Yaptığı Tarayıcı '] = 'socket_data.headers.user-agent'
      jsonFields['Giriş Yaptığı IP Adresi '] = 'socket_data.headers.cf-connecting-ip'
      jsonFields['Benzersiz Tarayıcı Kimliği '] = 'vid'
      jsonFields['Yayın Şifresi '] = 'pass'
      return jsonFields
    },
    project () {
      return this.$store.state.projects.project
    },
    projectTitle () {
      if (this.project) {
        const lang = this.project.languages.find(x => x.deletable === false).value
        return this.project.name[lang]
      }
      return 'Lütfen bekleyin'
    },
    saving () {
      return this.$store.state.projects.saving
    },
    fetching () {
      return this.$store.state.projects.fetching
    },
    questionTypes () {
      return [
        {
          name: 'string',
          label: this.$t('forms.questionTypes.string'),
          color: 'blue',
          icon: 'la la-font',
          type: 'simple'
        },
        {
          name: 'selectbox',
          label: this.$t('forms.questionTypes.selectbox'),
          color: 'orange',
          icon: 'la la-caret-square-down',
          type: 'simple'
        },
        {
          name: 'radio',
          label: this.$t('forms.questionTypes.radio'),
          color: 'green',
          icon: 'la la-dot-circle',
          type: 'simple',
          seperator: true
        }
      ]
    }
  }
}
</script>
<style>
thead tr:first-child th {
  font-size: 16px;
  font-weight: bold;
  border-bottom: 2px solid #000;
}
</style>

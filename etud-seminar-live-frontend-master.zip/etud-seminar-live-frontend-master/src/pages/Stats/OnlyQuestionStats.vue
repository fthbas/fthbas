<template>
  <div>
    <div class="row q-col-gutter-md q-pa-xl">
      <div class="col-12">
        <q-card>
          <q-card-section class="text-grey-8 shadow-2">
            <div class="row">
              <div class="col">
                <div class="text-h6">Sorular</div>
              </div>
              <div class="col-auto q-gutter-md">
                <q-btn icon-right="las la-plus" @click="rem = rem * 1.1" icon="las la-bold" color="green-8" label="Fontu Büyüt"></q-btn>
                <q-btn icon-right="las la-minus" @click="rem = rem * 0.9" icon="las la-font" color="red-5" label="Fontu Küçült"></q-btn>
              </div>
            </div>
          </q-card-section>
          <q-separator></q-separator>
          <q-card-section>
            <q-list>
              <q-item :key="qkey" v-for="(question, qkey ) in questions">
                <q-item-section>
                  <q-item-label  :style="{'font-size': (0.9 * rem) + 'rem'}">{{ question.first_name || '-' }} {{ question.last_name || '-' }}  || {{ question.lang && project.languages.find(x => x.value === question.lang) ? project.languages.find(x => x.value === question.lang).label : '' }}</q-item-label>
                  <p class="text-grey-8 q-pa-xs" :style="{'font-size': rem + 'rem'}">{{
                      question.q }}</p>
                </q-item-section>

                <q-item-section side top>
                  <q-item-label caption>{{ moment(question.created_at).locale('tr').fromNow() }}</q-item-label>
                  <q-icon class="cursor-pointer" name="las la-copy" color="grey-8" @click="()=>{copyToClipboard(
                    question.q
                    ); $q.notify({
                    message: 'Soru Kopyalandı',
                    color: 'green-8',
                    position: 'top'
                  })}" />
                </q-item-section>
              </q-item>
            </q-list>
          </q-card-section>
        </q-card>
      </div>
    </div>
  </div>
</template>
<script>
import moment from 'moment'
import { copyToClipboard } from 'quasar'
export default {
  name: 'Stats',
  data () {
    return {
      rem: 1,
      email_for_excel: '',
      copyToClipboard,
      prompt: false,
      moment,
      counter: 0,
      questions: null,
      survey: null,
      uniqueVisitors: 0,
      totalVisitors: 0,
      polling: null
    }
  },
  beforeRouteLeave (to, from, next) {
    this.$store.dispatch('projects/clearProject')
    clearInterval(this.polling)
    next()
  },
  beforeDestroy () {
    clearInterval(this.polling)
  },
  created () {
    // eslint-disable-next-line
    // window.$_REVECHAT_API.Button.hide()
    this.$store.dispatch('projects/fetchProjectByStats', { project: location.hostname, stats_password: this.$route.params.pass }).then(res => {
      this.$socket.client.emit('informQuestionsByPoint', this.project.domain)
      this.pollData()
    })
  },
  sockets: {
    questionsByPoint (d) {
      this.questions = d
    }
  },
  meta () {
    return {
      title: this.projectTitle,
      titleTemplate: title => `Sorular | ${title}`
    }
  },
  methods: {
    titleCase (sentence) {
      const sentences = sentence.toLowerCase().split('_')
      return sentences.join(' ')
    },
    pollData () {
      this.polling = setInterval(() => {
        this.$socket.client.emit('informQuestionsByPoint', this.project.domain)
      }, 10000)
    }
  },
  computed: {
    project () {
      return this.$store.state.projects.project
    },
    projectTitle () {
      const lang = this.project.languages.find(x => x.deletable === false).value
      if (this.project) {
        return this.project.name[lang]
      }
      return 'Lütfen bekleyin'
    },
    saving () {
      return this.$store.state.projects.saving
    },
    fetching () {
      return this.$store.state.projects.fetching
    }
  }
}
</script>
<style>

</style>

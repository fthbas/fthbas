export function setUser (state, user) {
  state.user = user
}

export function setErrors (state, errors) {
  state.errors = errors
}

export function setSaving (state, value) {
  state.saving = value
}

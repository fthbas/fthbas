export default function () {
  return {
    user: null,
    errors: null,
    saving: false
  }
}

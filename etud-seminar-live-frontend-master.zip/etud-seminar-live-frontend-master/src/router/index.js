import Vue from 'vue'
import VueRouter from 'vue-router'

import routes from './routes'
import { Cookies } from 'quasar'

Vue.use(VueRouter)

export default function () {
  const Router = new VueRouter({
    scrollBehavior: () => ({ x: 0, y: 0 }),
    routes,
    mode: process.env.VUE_ROUTER_MODE,
    base: process.env.VUE_ROUTER_BASE
  })

  const AUTH_NOT_REQUIRED_ROUTES = ['login']
  const ALWAYS_VISIBLE_ROUTES = ['unsubscribe', 'stats.u.t', 'stats.s.q', 'redirecter', 'redirect', 'live', 'live.login', 'live.pass', 'live.forgotPassword', 'live.register', 'live.registered_pass']
  Router.beforeEach((to, from, next) => {
    if (Cookies.get('bauth') === null) {
      // cookie yoksa
      if ((AUTH_NOT_REQUIRED_ROUTES.indexOf(to.name) < 0) && (ALWAYS_VISIBLE_ROUTES.indexOf(to.name) < 0)) {
        // rota loginlerde değilse
        next({
          name: 'login'
        })
      } else {
        // rota loginlerdeyse devam
        next()
      }
    } else {
      // cokkie varsa
      if (AUTH_NOT_REQUIRED_ROUTES.indexOf(to.name) > -1) {
        // loginlerdeyse
        next({
          name: 'dashboard'
        })
      } else {
        // değilse
        next()
      }
    }
  })

  return Router
}

const routes = [
  {
    path: '/etud-admin/sign-in',
    component: () => import('layouts/MainLayout.vue'),
    children: [
      { path: '', name: 'login', component: () => import('pages/Auth/Login.vue') }
    ]
  },
  {
    path: '/stats/u/p/t/',
    component: () => import('pages/Stats/Stats.vue'),
    name: 'stats.u.t'
  },
  {
    path: '/stats/s/q/s/:pass',
    component: () => import('layouts/StatsLayout.vue'),
    children: [
      { path: '', name: 'stats.s.q', component: () => import('pages/Stats/OnlyQuestionStats.vue') }
    ]
  },
  {
    path: '/etud-admin/',
    component: () => import('layouts/Dashboard.vue'),
    children: [
      { path: '', name: 'dashboard', component: () => import('pages/Dashboard/Home.vue') },
      { path: 'me', name: 'me', component: () => import('pages/Dashboard/Users/Me.vue') },
      { path: 'projects', name: 'projects', component: () => import('pages/Dashboard/Projects/Projects.vue') },
      { path: 'projects/create', name: 'projects.create', component: () => import('pages/Dashboard/Projects/CreateProject.vue') },
      { path: 'projects/:key', name: 'projects.show', component: () => import('pages/Dashboard/Projects/ShowProject.vue') }
    ]
  },
  { path: '/etud-admin/projects/:domain/stats/:pass', name: 'projects.stats', component: () => import('pages/Stats/Stats.vue') },
  {
    path: '/',
    component: () => import('layouts/Seminar.vue'),
    children: [
      { path: '', name: 'redirect', component: () => import('pages/Seminar/RedirectToDefaultLang.vue') },
      { path: '/:lang/login', name: 'live.login', component: () => import('pages/Seminar/Login.vue') },
      { path: '/:lang/register', name: 'live.register', component: () => import('pages/Seminar/Register.vue') },
      { path: '/:lang/forgot-password', name: 'live.forgotPassword', component: () => import('pages/Seminar/ForgotPassword.vue') }
    ]
  },
  {
    path: '/',
    component: () => import('layouts/StreamLayout.vue'),
    children: [
      { path: '/:lang', meta: { type: 'all' }, name: 'live', component: () => import('pages/Seminar/Live.vue') },
      { path: '/:lang/:pass', meta: { type: 'password' }, name: 'live.pass', component: () => import('pages/Seminar/Live.vue') },
      { path: '/:lang/u/:pass', meta: { type: 'registered' }, name: 'live.registered_pass', component: () => import('pages/Seminar/Live.vue') }
    ]
  }
]

export default routes
